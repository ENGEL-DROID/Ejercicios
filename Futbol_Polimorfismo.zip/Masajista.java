package futbol.polimorfismo;

public class Masajista extends SeleccionFutbol {
	
	protected String titulacion;
	protected int aniosExperiencia;
	
	protected Masajista(int id, String nombre, String apellidos, int edad, String titulacion, int aniosExperiencia) {
		super(id, nombre, apellidos, edad);
		this.titulacion = titulacion;
		this.aniosExperiencia = aniosExperiencia;
	}

	@Override
	protected void entrenamiento() {
		System.out.println("Masajista: " + super.getNombre() + " " + super.getApellidos() + ", Edad: " + super.getEdad() + ", Id: " + super.getId() + ", Titulaci�n: " + titulacion + ", A�os de Experiencia: " + aniosExperiencia);
	}
	
	protected void darMasaje() {
		System.out.println(super.getNombre() + " tiene que darse masajes todos los s�bados.");
	}

}
