package futbol.polimorfismo;

public class Futbolista extends SeleccionFutbol {
	
	protected int dorsal;
	protected String demarcacion;
	
	protected Futbolista(int id, String nombre, String apellidos, int edad, int dorsal, String demarcacion) {
		super(id, nombre, apellidos, edad);
		this.dorsal = dorsal;
		this.demarcacion = demarcacion;
	}

	@Override
	protected void entrenamiento() {
		System.out.println("Jugador: " + super.getNombre() + " " + super.getApellidos() + " realiza un entrenamiento.");
	}
	
	@Override
	protected void partidoFutbol() {
		System.out.println(super.getNombre() + " juega un partido.");
	}
	
	protected void entrevista() {
		System.out.println(super.getNombre() + " aspira a ser el mejor del mundo.");
	}
	
}
