package futbol.polimorfismo;

public class Principal {

	public static void main(String[] args) {

		SeleccionFutbol[] seleccion = new SeleccionFutbol[3];
		
		seleccion[0] = new Futbolista(8, "Thiago", "L�pez", 19, 3, "Delantero");
		seleccion[1] = new Entrenador(23, "Diego", "Luna", 22, 4035);
		seleccion[2] = new Masajista(14, "Jos�", "Torres", 28, "Superior", 6);
		
		for(int i=0; i<seleccion.length; i++) {
			seleccion[i].entrenamiento();
			seleccion[i].viajar();
			seleccion[i].concentrarse();
			seleccion[i].partidoFutbol();
			// para imprimir los m�todo propios de cada clase:
			if(seleccion[i].getClass().getName().equalsIgnoreCase("futbol.polimorfismo.Futbolista")) {
				((Futbolista) seleccion[i]).entrevista();
			}
			if(seleccion[i].getClass().getName().equalsIgnoreCase("futbol.polimorfismo.Entrenador")) {
				((Entrenador) seleccion[i]).planificarEntrenamiento();
			}
			if(seleccion[i].getClass().getName().equalsIgnoreCase("futbol.polimorfismo.Masajista")) {
				((Masajista) seleccion[i]).darMasaje();
			}
			System.out.println();
			
		}

	}

}
