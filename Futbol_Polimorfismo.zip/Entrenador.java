package futbol.polimorfismo;

public class Entrenador extends SeleccionFutbol {
	
	protected int idFederacion;

	protected Entrenador(int id, String nombre, String apellidos, int edad, int idFederacion) {
		super(id, nombre, apellidos, edad);
		this.idFederacion = idFederacion;
	}

	@Override
	protected void entrenamiento() {
		System.out.println("Entrenador: " + super.getNombre() + " " + super.getApellidos() + " Dirige un Entrenamiento");
	}
	
	@Override
	protected void partidoFutbol() {
		System.out.println(super.getNombre() + " dirige un partido.");
	}

	protected void planificarEntrenamiento() {
		System.out.println(super.getNombre() + " debe dirigir el entrenamiento todas las tardes de 15:00 a 18:00.");
	}
	
}
